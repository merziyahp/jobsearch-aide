// background.js - not used
